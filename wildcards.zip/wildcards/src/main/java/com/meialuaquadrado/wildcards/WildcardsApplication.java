package com.meialuaquadrado.wildcards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WildcardsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WildcardsApplication.class, args);
	}

}
