package com.meialuaquadrado.wildcards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WildcardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
